﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLaseantesdelparcial
{
    internal class Juego
    {
        public string Eq1 { get; set; }
        public string Eq2 { get; set;}
        public int Puntaje1 { get; set;}
        public int Puntaje2 { get;set;}
        public int Progreso { get; set; }

    }
}
